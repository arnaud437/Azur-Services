
export default function Contact() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>Contact</h1>
      <p>Envoyez-nous un message à : <a href="mailto:azur.services@gmail.com">azur.services@gmail.com</a></p>
    </div>
  )
}
