
export default function About() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>À propos</h1>
      <p>Nous sommes trois jeunes du Sud motivés à vous aider cet été.</p>
      <p>Avec Azur & Services, vous pouvez nous faire confiance pour garder vos enfants, nettoyer votre maison ou voiture, et même faire votre repassage !</p>
    </div>
  )
}
