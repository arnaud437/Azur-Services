
import Head from 'next/head'
import Link from 'next/link'
import { useState } from 'react'

export default function Home() {
  const [selected, setSelected] = useState([]);

  const services = [
    "Karcher (extérieur)",
    "Baby-sitting",
    "Nettoyage de maison",
    "Nettoyage de voiture",
    "Repassage"
  ];

  const toggleService = (s) => {
    setSelected((prev) =>
      prev.includes(s) ? prev.filter(item => item !== s) : [...prev, s]
    );
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <Head>
        <title>Azur & Services</title>
      </Head>
      <h1>Bienvenue chez Azur & Services</h1>
      <p>Composez la formule qui vous ressemble</p>
      <div>
        {services.map(service => (
          <div key={service} onClick={() => toggleService(service)} style={{
            margin: '8px 0',
            padding: '10px',
            border: '1px solid #ccc',
            cursor: 'pointer',
            backgroundColor: selected.includes(service) ? '#e0f7fa' : '#fff'
          }}>
            {service}
          </div>
        ))}
      </div>
      <h2>Votre formule :</h2>
      <ul>
        {selected.map(s => <li key={s}>{s}</li>)}
      </ul>
      <Link href='/contact'>Contactez-nous</Link>
    </div>
  )
}
